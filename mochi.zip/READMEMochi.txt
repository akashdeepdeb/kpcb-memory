Okay, these are the instructions to run this program

first of all, i love you the most and you are going to be my first
guinea pig to test this. we'll play this once we meet but first you
have to play it on your own. 

pagal

kkkkk....

you are too cute...

anyways,

no, stop being so cute, firstly...

we are not proceeding otherwise

....

still too cute mochi

.........

I can do this all day!!!!

no, cuteness is just constantly increasing omg...

fine, I suppose we have reached an impasse

.....

you are going to continue being a cutie pi but we have to proceed 

i have to go workout and have khana.... 
anyways... -___-

run this mochi:

go to terminal and `cd` into where this .zip has been opened:
`chmod +x memory.sh`
`./memory.sh`

have fun,
i love you, my cutie pi :*

made this only for you (and kpcb but that's just extra),
-mocha





